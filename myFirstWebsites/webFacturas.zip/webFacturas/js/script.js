let facturas = [{
		"numero": 1000,
		"fecha": "30-04-2019",
		"cliente": {
			"nif": "516667788A",
			"nombre": "Pepe Sánchez",
			"tlf": "61777888"
		},
		"detalle": [{
			"producto": "Impresora Láser",
			"precio": 85,
			"cantidad": 2
		}, {
			"producto": "CPU",
			"precio": 480,
			"cantidad": 1
		}, {
			"producto": "Disco duro portatil",
			"precio": 53,
			"cantidad": 2
		}]
	},
	{
		"numero": 1001,
		"fecha": "01-05-2019",
		"cliente": {
			"nif": "61777888J",
			"nombre": "Juan López",
			"tlf": "677888999"
		},
		"detalle": [{
			"producto": "Impresora de tinta",
			"precio": 45,
			"cantidad": 3
		}, {
			"producto": "Caja de 100 CDs",
			"precio": 12,
			"cantidad": 2
		}, {
			"producto": "Disco duro portatil",
			"precio": 51,
			"cantidad": 1
		}]
	}
];

function cargarSelect() {
	let texto = "";
	for (let i in facturas) {
		texto = 
			texto+"<option value='"+i+"'>"+
			facturas[i].numero+" / "+facturas[i].fecha
			"</option>";
	}
	document.getElementById("numFactura").innerHTML = texto;
}
function ver() {
	let listaFacturas = document.getElementById("numFactura");
	let pos = listaFacturas.value;


/* alert(listaFacturas.value);
alert(document.getElementById("numFactura").selectedIndex);
let pos = listaFacturas.selectedIndex;
alert(listaFacturas.options[pos].innerText);
*/
//mostramos los datos de la factura
let datos = "<p>Numero factura: "+ facturas[pos].numero + "</p>"
+ "<p>Fecha: " + facturas[pos].fecha + "</p>"
+ "<p>Cliente: "+ facturas[pos].cliente.nif + " - "
+ facturas[pos].cliente.nombre + " - "
+ facturas[pos].cliente.tlf + "</p>";

document.getElementById("datosFactura").innerHTML = datos;

//mostramos detalle de la factura

let detalles = facturas[pos].detalle;
let tabla = document.getElementById("detalleFactura");
let textoTabla = "";

for (let i in detalles) {
	textoTabla = textoTabla + "<tr>";
	textoTabla = textoTabla + "<td>";
	textoTabla = textoTabla + detalles[i].producto;
	textoTabla = textoTabla + "</td>";
	textoTabla = textoTabla + "<td>";
	textoTabla = textoTabla + detalles[i].precio;
	textoTabla = textoTabla + "</td>";
	textoTabla = textoTabla + "</tr>";
		textoTabla = textoTabla + "<tr>";
	textoTabla = textoTabla + "<td>";
	textoTabla = textoTabla + detalles[i].cantidad;
	textoTabla = textoTabla + "</td>";
	textoTabla = textoTabla + "<td>";
	textoTabla = textoTabla + detalles[i].precio*detalles[i];
	textoTabla = textoTabla + "</td>";
	textoTabla = textoTabla + "</tr>";
}
tabla.innerHTML = textoTabla;
}